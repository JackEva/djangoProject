from django.http import HttpResponse
from django.shortcuts import render



def sample(request):
    
    return HttpResponse("sample page")